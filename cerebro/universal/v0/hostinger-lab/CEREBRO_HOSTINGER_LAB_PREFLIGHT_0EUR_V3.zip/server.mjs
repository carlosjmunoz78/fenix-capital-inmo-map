/**
 * CEREBRO OS · Hostinger Business LAB V3 · safe read-only boot probe.
 * Direct .listen() at ESM evaluation time. No module-entry checks; Hostinger
 * may load the entry file as a module instead of launching `node server.mjs`.
 * NO credentials, Supabase, App/CRM, background jobs, file reads, or proxies.
 */
import {createServer} from 'node:http';

const headers = Object.freeze({
  'Cache-Control': 'no-store, max-age=0',
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'no-referrer',
  'Content-Security-Policy': "default-src 'none'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'"
});
const status = Object.freeze({
  status: 'READY', environment: 'LAB', operation: 'READ_ONLY_PREFLIGHT',
  owner_auth_test: 'NOT_RUN', prod_execution: 'DISABLED', background_jobs: 'DISABLED',
  probe_version: 'V3'
});

function reply(res, code, kind, body, head = false) {
  res.writeHead(code, {...headers, 'Content-Type': kind, 'Content-Length': Buffer.byteLength(body)});
  res.end(head ? undefined : body);
}

const server = createServer((req, res) => {
  // Strict routing. Never exposes filesystem contents, secrets, or arbitrary API actions.
  const path = req.url?.split('?')[0];
  const head = req.method === 'HEAD';
  if ((req.method === 'GET' || head) && path === '/healthz') {
    return reply(res, 200, 'application/json; charset=utf-8', JSON.stringify(status), head);
  }
  if ((req.method === 'GET' || head) && path === '/') {
    const html = '<!doctype html><html lang="es"><meta charset="utf-8">'+
      '<title>CEREBRO LAB | Hostinger V3</title><body><h1>CEREBRO LAB</h1>'+
      '<p>Hostinger Node.js: sonda V3 iniciada.</p>'+
      '<p>Sin credenciales, motores, trabajo programado o acceso a producción.</p></body></html>';
    return reply(res, 200, 'text/html; charset=utf-8', html, head);
  }
  reply(res, 404, 'application/json; charset=utf-8', '{"status":"NOT_FOUND"}', head);
});

// Hostinger requires listen() within 3 seconds. Do NOT protect this call with
// require.main, process.argv[1], realpath, or an asynchronous initialization.
const port = Number(process.env.PORT || 3000);
server.on('error', err => {
  process.stderr.write(`CEREBRO_LAB_V3_LISTEN_ERROR:${err.code || err.name}\n`);
  process.exitCode = 1;
});
server.listen(port, '0.0.0.0', () => {
  process.stdout.write('CEREBRO_LAB_V3_HTTP_READY\n');
});
