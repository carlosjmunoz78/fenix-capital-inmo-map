import test from 'node:test';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {createServer} from 'node:net';
import {mkdtemp, symlink, rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {fileURLToPath, pathToFileURL} from 'node:url';
import {resolve, join} from 'node:path';
import {setTimeout as delay} from 'node:timers/promises';

const entry = resolve(fileURLToPath(new URL('../server.mjs', import.meta.url)));
async function freePort(){
  const net=createServer();
  await new Promise((ok,fail)=>{net.once('error',fail);net.listen(0,'127.0.0.1',ok);});
  const port=net.address().port;
  await new Promise(ok=>net.close(ok));
  return port;
}
async function start({viaImport=false,viaSymlink=false}={}){
  const temp=await mkdtemp(join(tmpdir(),'cerebro-v3-'));
  const name=viaSymlink?join(temp,'current-server.mjs'):entry;
  if(viaSymlink)await symlink(entry,name);
  const port=await freePort();
  const args=viaImport?['--input-type=module','-e',`await import(${JSON.stringify(pathToFileURL(name).href)})`]:[name];
  const p=spawn(process.execPath,args,{cwd:temp,env:{...process.env,PORT:String(port),NODE_ENV:'production'},stdio:['ignore','pipe','pipe']});
  let stdout='',stderr='';p.stdout.on('data',b=>stdout+=b.toString());p.stderr.on('data',b=>stderr+=b.toString());
  for(let i=0;i<32;i++){
    if(p.exitCode!==null||p.signalCode)break;
    try{const r=await fetch(`http://127.0.0.1:${port}/healthz`,{signal:AbortSignal.timeout(200)});
      if(r.ok&&stdout.includes('CEREBRO_LAB_V3_HTTP_READY')) return {p,temp,port,stdout:()=>stdout,stderr:()=>stderr};
    }catch{}
    await delay(40);
  }
  p.kill('SIGTERM');await rm(temp,{recursive:true,force:true});
  assert.fail(`startup failed in 3 seconds: stdout=${stdout}; stderr=${stderr}; exit=${p.exitCode}`);
}
async function cleanup(ctx){
  ctx.p.kill('SIGTERM');
  await Promise.race([new Promise(r=>ctx.p.once('exit',r)),delay(500)]);
  await rm(ctx.temp,{recursive:true,force:true});
}
let ctx;
test.before(async()=>{ctx=await start();});
test.after(async()=>{if(ctx)await cleanup(ctx);});
const endpoint=path=>`http://127.0.0.1:${ctx.port}${path}`;
test('returns safe READY v3 JSON + security headers',async()=>{
  const r=await fetch(endpoint('/healthz'));
  assert.equal(r.status,200);
  assert.equal(r.headers.get('cache-control'),'no-store, max-age=0');
  assert.equal(r.headers.get('x-content-type-options'),'nosniff');
  assert.deepEqual(await r.json(),{
    status:'READY',environment:'LAB',operation:'READ_ONLY_PREFLIGHT',
    owner_auth_test:'NOT_RUN',prod_execution:'DISABLED',background_jobs:'DISABLED',probe_version:'V3'
  });
});
test('home HTML shows only probe; no inputs or secret fields',async()=>{
  const r=await fetch(endpoint('/'));
  assert.equal(r.status,200);const body=await r.text();
  assert.match(body,/Hostinger Node\.js/);
  assert.doesNotMatch(body,/<input|<form|password|service_role/i);
});
test('unlisted routes and secret paths remain inaccessible',async()=>{
  for(const path of ['/api/run','/api/auth','/.env','/server.mjs','/package.json','/test/server.test.mjs','/wp-admin']){
    assert.equal((await fetch(endpoint(path))).status,404,path);
  }
});
test('POST and mutation attempts are blocked',async()=>{
  assert.equal((await fetch(endpoint('/healthz'),{method:'POST',body:'{}'})).status,404);
  assert.equal((await fetch(endpoint('/api/run'),{method:'DELETE'})).status,404);
});
test('HEAD sends no body and disallows framing',async()=>{
  const r=await fetch(endpoint('/healthz'),{method:'HEAD'});
  assert.equal(r.status,200);
  assert.equal(await r.text(),'');
  assert.equal(r.headers.get('x-frame-options'),'DENY');
  assert.match(r.headers.get('content-security-policy'),/default-src 'none'/);
});
test('Hostinger loader import with no argv[1] unconditionally calls listen()',async()=>{
  const c=await start({viaImport:true});
  try{assert.equal((await (await fetch(`http://127.0.0.1:${c.port}/healthz`)).json()).status,'READY');}
  finally{await cleanup(c);}
});
test('Hostinger symlink entry starts unconditionally',async()=>{
  const c=await start({viaSymlink:true});
  try{assert.equal((await (await fetch(`http://127.0.0.1:${c.port}/healthz`)).json()).status,'READY');}
  finally{await cleanup(c);}
});
test('import loader via symlink starts unconditionally',async()=>{
  const c=await start({viaImport:true,viaSymlink:true});
  try{assert.equal((await (await fetch(`http://127.0.0.1:${c.port}/healthz`)).json()).status,'READY');}
  finally{await cleanup(c);}
});
